clear all;
n=12;
m=10;
map = [0,0,0; 1,1,1];


X6 = [1 1 1 1 1 1 1 2 2 2; %множество 6
     1 1 1 1 1 1 1 2 2 2;
     1 1 2 2 2 2 2 2 2 2;
     1 1 2 2 2 2 2 2 2 2
     1 1 1 1 1 1 1 2 2 2;
     1 1 1 1 1 1 1 2 2 2;
     1 1 2 2 2 1 1 2 2 2;
     1 1 2 2 2 1 1 2 2 2;
     1 1 2 2 2 1 1 2 2 2;
     1 1 2 2 2 1 1 2 2 2;
     1 1 1 1 1 1 1 2 2 2;
     1 1 1 1 1 1 1 2 2 2];


X3 =    [2 2 2 1 1 1 1 1 1 1 ;
         2 2 2 1 1 1 1 1 1 1 
         2 2 2 2 2 2 2 2 1 1 ;
         2 2 2 2 2 2 2 2 1 1 ;
         2 2 2 2 2 2 2 2 1 1 ;
         2 2 2 1 1 1 1 1 1 1 ;
         2 2 2 1 1 1 1 1 1 1 ;
         2 2 2 2 2 2 2 2 1 1 ;
         2 2 2 2 2 2 2 2 1 1 ;
         2 2 2 2 2 2 2 2 1 1 ;
         2 2 2 1 1 1 1 1 1 1 ;
         2 2 2 1 1 1 1 1 1 1 ];  %множество 3
 
X9 =    [2 2 2 1 1 1 1 1 1 1 ;
         2 2 2 1 1 1 1 1 1 1 
         2 2 2 1 1 2 2 2 1 1 ;
         2 2 2 1 1 2 2 2 1 1 ;
         2 2 2 1 1 2 2 2 1 1 ;
         2 2 2 1 1 2 2 2 1 1 ;
         2 2 2 1 1 1 1 1 1 1 ;
         2 2 2 1 1 1 1 1 1 1 ;
         2 2 2 2 2 2 2 2 1 1 ;
         2 2 2 2 2 2 2 2 1 1 ;
         2 2 2 1 1 1 1 1 1 1 ;
         2 2 2 1 1 1 1 1 1 1 ];  %множество 9
  
     
 figure;
image(X6);
title('Image 6')
colormap(map); %отрисовка цифры 6
axis off; 
axis image;       
 

figure;
image(X3); 
title('Image 3')
colormap(map); %отрисовка цифры 3
axis off; 
axis image;

figure; 
image(X9);
title('Image 9')
colormap(map); %отрисовка цифры 9
axis off; 
axis image;


%Перевод из эталоныных образов в векторы
p6 = matrix_to_vector(X6,n,m);
p3 = matrix_to_vector(X3,n,m); 
p9 = matrix_to_vector(X9,n,m);

T = [p6; p3; p9]';
net.trainParam.epoch=600; %кол-во эпох
net = newhop(T); %сеть Хопфилда
display(net);
view(net);
Ai = T;
Y = sim(net,3,[],Ai);

%ПЕРВЫЙ ОБРАЗ
T6=vector_to_matrix(Y(:,1),n,m); %преобразование вектора в матрицу 12*10
figure;
image(T6);
title('Output Image 6')
colormap(map);
axis off;
axis image; 


%ВТОРОЙ ОБРАЗ
p = rand(n,m); %матрица шума
X61=noise(X6,n,m,p,0.2);
X31=noise(X3,n,m,p,0.2);%шум для второго образа
X91=noise(X9,n,m,p,0.2); 

figure;
image(X31); 
title('Input Image 3')
colormap(map);
axis off;
axis image;
p61=matrix_to_vector(X61,n,m);
p31=matrix_to_vector(X31,n,m);
p91=matrix_to_vector(X91,n,m);
Ai = [p61; p31; p91]';
[Y] = sim(net,3,[],Ai);
Y;


T3=vector_to_matrix(Y(:,2),n,m);

figure;
image(T3); 
title('Output Image 3')
colormap(map);
axis off;
axis image;


%ТРЕТИЙ ОБРАЗ

X91=noise(X9,n,m,p,0.3); %шум для третьего образа 30%
p61=matrix_to_vector(X61,n,m);
p31=matrix_to_vector(X31,n,m);
p91=matrix_to_vector(X91,n,m);
Ai = [p61; p31; p91]';
[Y] = sim(net,3,[],Ai);
[Y] = sim(net,3,[],Y);
Y;


figure;
image(X91);
title('Input Image 9')
colormap(map);
axis off;
axis image;

T9=vector_to_matrix(Y(:,3),n,m);
figure;
image(T9); 
title('Output Image 9')
colormap(map);
axis off;
axis image




%ФУНКЦИИ
function T = matrix_to_vector(X,n,m)
     for i=1:n
         for j=1:m
             if (X(i,j)==2)
                 T(i,j)=1;
             else
                 T(i,j)=-1;
             end
         end
     end
     T = reshape(T',1,[]);
end

function X = vector_to_matrix(T,n,m)
     for i=1:n*m
         if (T(i)>0)
            X(i)=2;
         end
         if (T(i)<0) 
            X(i)=1;
         end
     end
     X = reshape(X,m,n);
     X=X';
end

function X = noise(X,n,m,p,p0)
     for i=1:n
         for j=1:m
             if (p(i,j)<=p0)
                 if (X(i,j)==2)
                    X(i,j)=1;
                 else
                    X(i,j)=2;
                 end
             end 
         end
     end
end
