clear all
a = 0.
b = 3.5
h = 0.01
t = a:h:b;
x_ = @ (t) sin(sin(t).*t.^2 + 5.*t);
x = x_(t) 

figure;
gr=plot(t,x); grid;
split_part = 0.1
m = length(t) 
m
n = round(m - split_part*m)
n
set(gr(1), 'LineStyle', '-', 'Color', 'r', 'LineWidth', 2);
title('Reference')
[trainInd,testInd] = divideind(size(x,2),1:n,n:m);%разделение множества
%[trainInd,testInd] = dividerand(size(x,2),0.8,0.2);

Train_x = t(trainInd);
Train_y=x(trainInd); 
Test_x = t(testInd);
Test_y=x(testInd);

spread = h;
net = newgrnn(Train_x,Train_y,spread); %создание сети
display(net); view(net);

xr=sim(net,Train_x);	%выход сети для обучающего подмножества
xs=sim(net,Test_x);	%выход сети для тестового подмножества

figure; 
subplot(211);
gr=plot(t,x,Train_x,xr,Test_x,xs); grid; title('Reference & Predict values');
set(gr(1), 'LineStyle', '-', 'Color', 'r', 'LineWidth', 2);
set(gr(2), 'Marker', 'o', 'Color', 'g', 'LineWidth', 2, 'LineStyle', 'none');
set(gr(3), 'Marker', 'o', 'Color', 'b', 'LineWidth', 2, 'LineStyle', 'none');
legend('Reference values', 'Train values', 'Test Values')

E_train = abs(Train_y - xr);
E_test= abs(Test_y - xs);

subplot(212);
gr = plot(Train_x, E_train, Test_x, E_test); 
grid; 
title('Error Curve');
set(gr(1), 'LineStyle', '-', 'Color', 'g', 'LineWidth', 2);
set(gr(2), 'Marker', 'o', 'Color', 'b', 'LineWidth', 2, 'LineStyle', 'none');
legend('Train Error', 'Test Error')

SSE_test = sum((Test_y-xs).^2); %сумма квадратов ошибок
SSyy_test = sum((Test_y-mean(Test_y)).^2);
R2_test = 1 - SSE_test/SSyy_test

SSE_train = sum((Train_y-xr).^2); %сумма квадратов ошибок
SSyy_train = sum((Train_y-mean(Train_y)).^2); 
R2_train = 1 - SSE_train/SSyy_train

MSE_train = mse(xr-Train_y)
RMSE_train = sqrt(MSE_train)
SKO_train = RMSE_train/(max(Train_y)-min(Train_y)) %Относительная СКО,
%
MAE_train = mae(E_train)
MIN_train = min(abs(E_train)) %min 
MAX_train = max(abs(E_train)) %max
MAPE_train = mean((abs(xr-Train_y))./Train_y)

MSE_test = mse(xs-Test_y) 
RMSE_test = sqrt(MSE_test)
SKO_test = RMSE_test/(max(Test_y)-min(Test_y)) %Относительная СКО, %
MAE_test = mae(E_test)
MIN_test = min(abs(E_test)) %min absolute error 
MAX_test = max(abs(E_test)) %max absolute error 
MAPE_test = mean((abs(xs-Test_y))./Test_y)

E05 = 0;E05_10 = 0;E10_20 = 0;E20_30 = 0;E30 = 0;
for i=1:length(E_train)
if abs(E_train(i))<0.05	% Доля с ошибкой менее 5%, %
E05=E05+1;
end
if (abs(E_train(i))>=0.05) && (abs(E_train(i))<0.1) % Доля с ошибкой от 5% до 10%, %
E05_10 = E05_10+1;
end
if (abs(E_train(i))>=0.1) && (abs(E_train(i))<0.2) % Доля с ошибкой от 10% до 20%, %
E10_20 = E10_20+1;
end
if (abs(E_train(i))>=0.2) && (abs(E_train(i))<0.3) % Доля с ошибкой от 20% до 30%, %
E20_30 = E20_30+1;
end
if (abs(E_train(i))>=0.3)	% Доля с ошибкой более 30%, %
E30 = E30+1;
end
end
E05 = E05/length(E_train) % Доля с ошибкой менее 5%, %
E05_10 = E05_10/length(E_train) % Доля с ошибкой от 5% до 10%, %
E10_20 = E10_20/length(E_train) % Доля с ошибкой от 10% до 20%, % 
E20_30 = E20_30/length(E_train) % Доля с ошибкой от 20% до 30%, %
E30 = E30/length(E_train) % Доля с ошибкой более 30%, %
E05_test = 0;E05_10_test = 0;E10_20_test = 0;E20_30_test = 0;
E30_test = 0;
for i=1:length(E_test)
if abs(E_test(i))<0.05	% Доля с ошибкой менее 5%, %
E05_test=E05_test+1;
end
if (abs(E_test(i))>=0.05) && (abs(E_test(i))<0.1) % Доля с ошибкой от 5% до 10%, %
E05_10_test = E05_10_test+1;
end
if (abs(E_test(i))>=0.1) && (abs(E_test(i))<0.2) % Доля с ошибкой от 10% до 20%, %
E10_20_test = E10_20_test+1;
end
if (abs(E_test(i))>=0.2) && (abs(E_test(i))<0.3) % Доля с ошибкой от 20% до 30%, %
E20_30_test = E20_30_test+1;
end
if (abs(E_test(i))>=0.3)	% Доля с ошибкой более 30%, %
E30_test = E30_test+1;
end
end
E05_test = E05_test/length(E_test) % Доля с ошибкой менее 5%, %
E05_10_test = E05_10_test/length(E_test) % Доля с ошибкой от 5% до 10%, %
E10_20_test = E10_20_test/length(E_test) % Доля с ошибкой от 10% до
20%, %
E20_30_test = E20_30_test/length(E_test) % Доля с ошибкой от 20% до
30%, %
E30_test = E30_test/length(E_test) % Доля с ошибкой более 30%, %
