clear all;

t=0:0.025:2*pi; %генерация точек

a=0.4; b=0.15; alpha=pi/6; x0=0; y0=0; %Эллипс №2

x1 = @ (t) x0 + a*cos(t)*cos(alpha) + b*sin(t)*sin(alpha);
y1 = @ (t) y0 - a*cos(t)*sin(alpha) + b*sin(t)*cos(alpha);

x1=x1(t);
y1=y1(t);


a=0.7; b=0.5; alpha=-pi/3; x0=0; y0=0; %Эллипс №2

x2 = @ (t) x0 + a*cos(t)*cos(alpha) + b*sin(t)*sin(alpha);
y2 = @ (t) y0 - a*cos(t)*sin(alpha) + b*sin(t)*cos(alpha);

 
x2=x2(t);
y2=y2(t);

 
a=1; b=1; alpha=0; x0=0; y0=0; %Эллипс №3

x3 = @ (t) x0 + a*cos(t)*cos(alpha) + b*sin(t)*sin(alpha);
y3 = @ (t) y0 - a*cos(t)*sin(alpha) + b*sin(t)*cos(alpha);

 
x3=x3(t);
y3=y3(t);
 


 

k = size (t, 2);

p1 = randperm (k, 60);	%генерация множества точек 
p2 = randperm(k, 100);
p3 = randperm(k, 120);

X1 = x1(p1);
Y1 = y1(p1);

X2 = x2(p2);
Y2 = y2(p2);

X3 = x3(p3);
Y3 = y3(p3);


figure;
gr = plot(x1, y1, x2, y2, x3, y3, X1, Y1, X2, Y2, X3, Y3);
axis([-1.2 1.2 -1.2 1.2]);
grid;

set(gr(1), 'LineStyle', '-', 'Color', 'r', 'LineWidth', 2);
set(gr(2), 'LineStyle', '-', 'Color', 'g', 'LineWidth', 2);
set(gr(3), 'LineStyle', '-', 'Color', 'b', 'LineWidth', 2);
set(gr(4), 'Marker', 'o', 'Color', 'r', 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'r', 'MarkerSize', 7, 'LineStyle', 'none'); set(gr(5), 'Marker', 'o', 'Color', 'g', 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'g', 'MarkerSize', 7, 'LineStyle', 'none'); set(gr(6), 'Marker', 'o', 'Color', 'b', 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'b', 'MarkerSize', 7, 'LineStyle', 'none');
title('Generated Sets')
legend('Class 1','Class 2','Class 3');



[trainInd1, valInd1, testInd1] = dividerand(60, 0.8, 0, 0.2);
%разделение множества на обучающее
[trainInd2, valInd2, testInd2] = dividerand(100, 0.8, 0, 0.2); % контрольное и тестовое
[trainInd3, valInd3, testInd3] = dividerand(120, 0.8, 0, 0.2);
 
train1X=X1(trainInd1); train1Y=Y1(trainInd1);	%Обучающее множество
train2X=X2(trainInd2); train2Y=Y2(trainInd2); 
train3X=X3(trainInd3); train3Y=Y3(trainInd3);

for i=1:size(train1X,2) %Эталоны 
    train1t(i)=1;
end

for i=1:size(train2X,2)
    train2t(i)=2;
end

for i=1:size(train3X,2)
    train3t(i)=3;
end

test1X=X1(testInd1); test1Y=Y1(testInd1);	% Тестовое множество
test2X=X2(testInd2); test2Y=Y2(testInd2); test3X=X3(testInd3); test3Y=Y3(testInd3);

for i=1:size(test1X,2)	%Эталоны 
    test1t(i)=1;
end

for i=1:size(test2X,2)
    test2t(i)=2;
end

for i=1:size(test3X,2)
    test3t(i)=3;
end

figure; 
gr=plot(x1,y1,x2,y2,x3,y3,train1X,train1Y,train2X,train2Y,train3X,train3Y,test1X,test1Y,test2X,test2Y,test3X,test3Y);

axis([-1.2 1.2 -1.2 1.2]); %границы множества grid;

set(gr(1), 'LineStyle', '-', 'Color', 'r', 'LineWidth', 2);
set(gr(2), 'LineStyle', '-', 'Color', 'g', 'LineWidth', 2);
set(gr(3), 'LineStyle', '-', 'Color', 'b', 'LineWidth', 2);
set(gr(4), 'Marker', 'o', 'Color', 'r', 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'r', 'MarkerSize', 7, 'LineStyle', 'none'); set(gr(5), 'Marker', 'o', 'Color', 'g', 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'g', 'MarkerSize', 7, 'LineStyle', 'none'); set(gr(6), 'Marker', 'o', 'Color', 'b', 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'b', 'MarkerSize', 7, 'LineStyle', 'none'); set(gr(7), 'Marker', 'V', 'Color', 'r', 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'c', 'MarkerSize', 7, 'LineStyle', 'none');
 
set(gr(8), 'Marker', 'V', 'Color', 'g', 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'c', 'MarkerSize', 7, 'LineStyle', 'none'); set(gr(9), 'Marker', 'V', 'Color', 'b', 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'c', 'MarkerSize', 7, 'LineStyle', 'none'); 
title('Split to Train & Test Sets')
legend('Class 1','Class 2','Class 3','Train Class 1','Train Class 2','Train Class 3', 'Test','','');

trainX=[train1X,train2X,train3X];
trainY=[train1Y,train2Y,train3Y];
testX=[test1X,test2X,test3X];
testY=[test1Y,test2Y,test3Y];
traint=[train1t,train2t,train3t]; %Эталонные значения
testt=[test1t,test2t,test3t];

T=ind2vec(traint);%Эталонное распределение точек обучающей выборки по классам

%spread=0.3; %ширина купола гауссиана
spread=0.1;

net = newpnn([trainX;trainY],T,spread);% Создание сети с spread 
display(net);
view(net);

Y=sim(net,[trainX;trainY]); %выход сети для обучающего подмножества
Yc=vec2ind(Y); Z=abs(Yc-traint); N=size(traint,2); p=0;
for i=1:N
if not(Z(i)==0) p=p+1;
end
end
probtrain = ((N-p)/N)*100 %процент правильно классифицированных точек

Y_test=sim(net,[testX;testY]); %выход сети для для тестового подмножества
Yc_test=vec2ind(Y_test);
Z_test=abs(Yc_test-testt); 
N_test=size(testt,2);
p=0;
for i=1:N_test
    if not(Z_test(i)==0)
        p=p+1;
    end
end
 
probtest = ((N_test-p)/N_test)*100 %процент правильно классифицированных точек


xs=-1.2:0.025:1.2;
ys=-1.2:0.025:1.2; %генерирование сетки
for i=1:size(xs,2)	% выход сети для всех узлов сетки.
    for j=1:size(xs,2)
        Xs(i,j)=xs(i); 
        Ys(i,j)=ys(j);
    end
end

X=[];
for i=1:size(xs,2) 
    X=[X,Xs(i,:)];
end

Y=[];
for i=1:size(xs,2) 
    Y=[Y,Ys(i,:)];
end

Pp=[X;Y];
Zz=sim(net, Pp);
Zz=vec2ind(Zz);

xa1=[];
ya1=[];
for i=1:size(Zz,2)
    if Zz(i)==1
        xa1=[xa1,X(i)];
        ya1=[ya1,Y(i)];
    end
end

xa2=[];
ya2=[];
for i=1:size(Zz,2)
    if Zz(i)==2
        xa2=[xa2,X(i)];
        ya2=[ya2,Y(i)];
    end
end

xa3=[];
ya3=[];
for i=1:size(Zz,2) 
    if Zz(i)==3
        xa3=[xa3,X(i)];
        ya3=[ya3,Y(i)];
    end
end

figure;
gr2=plot(xa1,ya1,xa2,ya2,xa3,ya3,x1,y1,x2,y2,x3,y3);
legend('Predict Class 1', 'Predict Class 2', 'Predict Class 3', 'Class 1', 'Class 2', 'Class 3')
set(gr2(4), 'LineStyle', '-', 'Color', 'r', 'LineWidth', 2);
set(gr2(5), 'LineStyle', '-', 'Color', 'g', 'LineWidth', 2);
set(gr2(6), 'LineStyle', '-', 'Color', 'b', 'LineWidth', 2);
set(gr2(1), 'Marker', 'o', 'Color', 'r','MarkerSize', 7, 'LineStyle', 'none');
set(gr2(2), 'Marker', 'o', 'Color', 'g','MarkerSize', 7, 'LineStyle', 'none');
set(gr2(3), 'Marker', 'o', 'Color', 'b','MarkerSize', 7, 'LineStyle', 'none');
title('Classifier Sets')

