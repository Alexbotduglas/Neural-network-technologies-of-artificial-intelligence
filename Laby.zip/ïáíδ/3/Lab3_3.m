clear all
a = 0.
b = 3.5
t = a:0.01:b;
x_ = @ (t) sin(sin(t).*t.^2 + 5.*t);
x = x_(t) 

figure;
gr=plot(t,x); grid;
split_part = 0.1
m = length(t) 
m
n = round(m - split_part*m)
n
set(gr(1), 'LineStyle', '-', 'Color', 'r', 'LineWidth', 2);
title('Function for Trainig')
[trainInd,valInd] = divideind(size(x, 2), 1:(n + 1), n:(m+1)); %разделение множества
Trx=t(trainInd);
Valx=t(valInd);

Try=x(trainInd);
Valy=x(valInd);

net=feedforwardnet(20, 'trainbfg');	%создание сети
net=configure(net, [a, b], [-1.,1.]); %конфигурация сети под обучающее множество


net.divideFcn='divideind';
net.divideParam.trainInd=1:n; %обучающее подмножество
net.divideParam.valInd= n:m; %контрольное подмножество
net.divideParam.testInd=[];
net.layers{1}.transferFCn = 'tansig';
net.layers{2}.transferFCn = 'purelin';

init(net); %инициализация сети
display(net);
%view(net);
 
IW = net.iw{1}
LW2 = net.lw{2}

net.trainParam.epochs=600;	%задание параметров (эпох)
net.trainParam.max_fail=600;
net.trainParam.goal=1E-8;	%точность

P=[Trx,Valx];	%формирование выходных множеств
T=[Try,Valy];
net = train(net,P,T);

xr=sim(net,Trx);
xv=sim(net,Valx);

figure; 
subplot(211)
gr=plot(t,x,Trx,xr,Valx,xv);
grid;
set(gr(1), 'LineStyle', '-', 'Color', 'r', 'LineWidth', 2);
set(gr(2), 'LineStyle', '-', 'Color', 'g', 'LineWidth', 2);
set(gr(3), 'LineStyle', '-', 'Color', 'b', 'LineWidth', 2);
title('After Training')
legend('Base', 'Train', 'Validation')
E = xr - Try; %вычисление погрешности
EE = xv - Valy; %вычисление погрешности 
subplot(212)
plot(Trx, E, 'g', Valx, EE, 'b'); grid; %график ошибки
M_train = sqrt(mse(xr - Try)) %расчет среднеквадратичной ошибки
M_val = sqrt(mse(xv - Valy))
E = xr - Try; %вычисление погрешности

M2 = sqrt(mse(xr - Try))
%таблица 2
SKO = M2/(max(xr)-min(xr))
SSE = sum((xr - Try).*(xr - Try)) %сумма квадратов ошибок
SSyy = sum((xr-mean(xr)).^2)
R2 = 1 - SSE/SSyy
MSE = mse(xr - Try)
MAE = mae(E)
MIN = min(abs(E))
MAX = max(abs(E))
E1 = 0;E2 = 0;E3 = 0;E4 = 0;E5 = 0;
for i=1:length(E)
    if abs(E(i))<0.05
        E1=E1+1;
    end;
    if (abs(E(i))>=0.05) && (abs(E(i))<0.1)
        E2 = E2+1;
    end;
    if (abs(E(i))>=0.1) && (abs(E(i))<0.2)
        E3 = E3+1;
    end;
    if (abs(E(i))>=0.2) && (abs(E(i))<0.3)
        E4 = E4+1;
    end;
    if (abs(E(i))>=0.3)
        E5 = E5+1;
    end;
end;
E1 = E1/length(E)
E2 = E2/length(E)
E3 = E3/length(E) 
E4 = E4/length(E) 
E5 = E5/length(E)
 
EE = xv - Valy; %вычисление погрешности

M2 = sqrt(mse(xv - Valy))
%таблица 2
SKO = M2/(max(xv)-min(xv))
SSE = sum((xv - Valy).*(xv - Valy)) %сумма квадратов ошибок SSyy = sum((xv-mean(xv)).^2)
R2 = 1 - SSE/SSyy
MSE = mse(xv - Valy)
MAE = mae(EE)
MIN = min(abs(EE))
MAX = max(abs(EE))
E11 = 0;E22 = 0;E33 = 0;E44 = 0;E55 = 0;
for i=1:length(EE)
    if abs(EE(i))<0.05
        E11=E11+1;
    end;
    if (abs(EE(i))>=0.05) && (abs(EE(i))<0.1)
        E22 = E22+1;
    end;
    if (abs(EE(i))>=0.1) && (abs(EE(i))<0.2) 
        E33 = E33+1;
    end;
    if (abs(EE(i))>=0.2) && (abs(EE(i))<0.3)
        E44 = E44+1;
    end;
    if (abs(EE(i))>=0.3)
        E55 = E55+1;
    end;
end;
E11 = E11/length(EE)
E22 = E22/length(EE)
E33 = E33/length(EE)
E44 = E44/length(EE) 
E55 = E55/length(EE)