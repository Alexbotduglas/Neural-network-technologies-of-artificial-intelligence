clear all
close all

k1 = 0:0.025:1;
k2 = 0.48:0.025:2.71;

g = sin(sin(k).*k.*k) - 0.1;


