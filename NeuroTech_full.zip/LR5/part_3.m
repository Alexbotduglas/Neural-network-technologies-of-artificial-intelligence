clear all
close all

%3 6 0

n = 12;
m = 10;

map = [0, 0, 0; 1, 1, 1];

X3=[2 2 1 1 1 1 1 1 2 2;
    2 2 1 1 1 1 1 1 1 2;
    2 2 2 2 2 2 2 1 1 2;
    2 2 2 2 2 2 2 1 1 2;
    2 2 2 2 2 2 2 1 1 2;
    2 2 2 2 1 1 1 1 2 2;
    2 2 2 2 1 1 1 1 2 2;
    2 2 2 2 2 2 2 1 1 2;
    2 2 2 2 2 2 2 1 1 2;
    2 2 2 2 2 2 2 1 1 2;
    2 2 1 1 1 1 1 1 1 2;
    2 2 1 1 1 1 1 1 2 2];

X6=[1 1 1 1 1 1 1 1 2 2;
    1 1 1 1 1 1 1 1 2 2;
    1 1 2 2 2 2 2 2 2 2;
    1 1 2 2 2 2 2 2 2 2;
    1 1 1 1 1 1 1 1 2 2;
    1 1 1 1 1 1 1 1 2 2;
    1 1 2 2 2 2 1 1 2 2;
    1 1 2 2 2 2 1 1 2 2;
    1 1 2 2 2 2 1 1 2 2;
    1 1 2 2 2 2 1 1 2 2;
    1 1 1 1 1 1 1 1 2 2;
    1 1 1 1 1 1 1 1 2 2];

X0=[2 2 2 2 2 2 2 2 2 2; %0 
    2 2 2 1 1 1 1 2 2 2;
    2 2 1 1 1 1 1 1 2 2;
    2 1 1 1 2 2 1 1 1 2;
    2 1 1 1 2 2 1 1 1 2;
    2 1 1 1 2 2 1 1 1 2;
    2 1 1 1 2 2 1 1 1 2;
    2 1 1 1 2 2 1 1 1 2;
    2 1 1 1 2 2 1 1 1 2;
    2 2 1 1 1 1 1 1 2 2;
    2 2 2 1 1 1 1 2 2 2;
    2 2 2 2 2 2 2 2 2 2];

figure;
map = [0, 0, 0; 1, 1, 1];
image(X3); colormap(map)
axis off
axis image

figure;
map = [0, 0, 0; 1, 1, 1];
image(X6); colormap(map)
axis off
axis image

figure;
map = [0, 0, 0; 1, 1, 1];
image(X0); colormap(map)
axis off
axis image

p3 = [];
p6 = [];
p0 = [];

for i = 1:n
for j = 1:m
if X3(i,j) == 1
    p3 = [p3,-1];
end;
if X3(i,j) == 2
    p3 = [p3,1];
end;
end;
end;

for i = 1:n
for j = 1:m
if X6(i,j) == 1
    p6 = [p6,-1];
end;
if X6(i,j) == 2
    p6 = [p6,1];
end;
end;
end;

for i = 1:n
for j = 1:m
if X0(i,j) == 1
    p0 = [p0,-1];
end;
if X0(i,j) == 2
    p0 = [p0,1];
end;
end;
end;

IW = [p3; p6; p0];
b1 = [m*n;m*n;m*n];

epsilon = 1/2;

for i=1:3
    for j=1:3
        LW(i,j)=-epsilon;
        if i == j
            LW(i,j)=1;
        end;
    end;
end;

T = [p3;p6;p0]';
a1 = IW*T+[b1,b1,b1];

net = newhop(a1);
net.layers{1}.transferFcn = 'poslin';
% net.trainParam.epochs=600;

display(net);
view(net);

net.LW{1,1}=LW;
net.b{1}=[0;0;0];

T = [p3;p6;p0]';
Ai = IW*T+[b1,b1,b1];
Y=sim(net,3,[],Ai);
% Y=sim(net,3,[],Y);

Y=Y(:,1);

if not(Y(1)==0)
    X=X3;
else
    if not(Y(2)==0)
        X=X6;
    else
        if not(Y(3)==0)
            X=X0;
        else
            return;
        end;
    end;
end;

%%%
X3_n = X3;
p_rand = rand(12,10);

for i=1:n
    for j=1:m
        if p_rand(i,j) < 0.1
            if X3_n(i,j) == 2
                X3_n(i,j) = 1;
            else
                X3_n(i,j) = 2;
            end;
        end;
    end;
end;

X6_n = X6;

for i=1:n
    for j=1:m
        if p_rand(i,j) < 0.2
            if X6_n(i,j) == 2
                X6_n(i,j) = 1;
            else
                X6_n(i,j) = 2;
            end;
        end;
    end;
end;

X0_n = X0;

for i=1:n
    for j=1:m
        if p_rand(i,j) < 0.3
            if X0_n(i,j) == 2
                X0_n(i,j) = 1;
            else
                X0_n(i,j) = 2;
            end;
        end;
    end;
end;

p3_n = [];
p6_n = [];
p0_n = [];

for i = 1:n
for j = 1:m
if X3_n(i,j) == 1
    p3_n = [p3_n,-1];
end;
if X3_n(i,j) == 2
    p3_n = [p3_n,1];
end;
end;
end;

for i = 1:n
for j = 1:m
if X6_n(i,j) == 1
    p6_n = [p6_n,-1];
end;
if X6_n(i,j) == 2
    p6_n = [p6_n,1];
end;
end;
end;

for i = 1:n
for j = 1:m
if X0_n(i,j) == 1
    p0_n = [p0_n,-1];
end;
if X0_n(i,j) == 2
    p0_n = [p0_n,1];
end;
end;
end;

T = [p3_n;p6_n;p0_n]';
Ai = IW*T+[b1,b1,b1];
Y = sim(net,3,[],Ai);
% Y = sim(net,3,[],Y);
% Y = sim(net,3,[],Y);

Y_1=Y(:,1);
[argvalue_1, argmax_1] = max(Y_1);
Y_2=Y(:,2);
[argvalue_2, argmax_2] = max(Y_2);
Y_3=Y(:,3);
[argvalue_3, argmax_3] = max(Y_3);

figure;
image(X6_n); colormap(map);
axis off;
axis image;

figure;
image(X0_n); colormap(map);
axis off;
axis image;

argmax_1
argmax_2
argmax_3

% figure;
% image(X);colormap(map);

axis off;
axis image;