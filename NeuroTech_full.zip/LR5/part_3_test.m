clear all;
n=12;
m=10;
map = [0,0,0; 1,1,1];
X6 = [1 1 1 1 1 1 1 2 2 2; %��������� 6
 1 1 1 1 1 1 1 2 2 2;
 1 1 2 2 2 2 2 2 2 2;
 1 1 2 2 2 2 2 2 2 2
 1 1 1 1 1 1 1 2 2 2;
 1 1 1 1 1 1 1 2 2 2;
 1 1 2 2 2 1 1 2 2 2;
 1 1 2 2 2 1 1 2 2 2;
 1 1 2 2 2 1 1 2 2 2;
 1 1 2 2 2 1 1 2 2 2;
 1 1 1 1 1 1 1 2 2 2;
 1 1 1 1 1 1 1 2 2 2];
X3 = [2 2 2 1 1 1 1 1 1 1 ;
 2 2 2 1 1 1 1 1 1 1
 2 2 2 2 2 2 2 2 1 1 ;
 2 2 2 2 2 2 2 2 1 1 ;
 2 2 2 2 2 2 2 2 1 1 ;
 2 2 2 1 1 1 1 1 1 1 ;
 2 2 2 1 1 1 1 1 1 1 ;
 2 2 2 2 2 2 2 2 1 1 ;
 2 2 2 2 2 2 2 2 1 1 ;
 2 2 2 2 2 2 2 2 1 1 ;
 2 2 2 1 1 1 1 1 1 1 ;
 2 2 2 1 1 1 1 1 1 1 ]; %��������� 3
X9 = [2 2 2 1 1 1 1 1 1 1 ;
 2 2 2 1 1 1 1 1 1 1
 2 2 2 1 1 2 2 2 1 1 ;
 2 2 2 1 1 2 2 2 1 1 ;
 2 2 2 1 1 2 2 2 1 1 ;
 2 2 2 1 1 2 2 2 1 1 ;
 2 2 2 1 1 1 1 1 1 1 ;
 2 2 2 1 1 1 1 1 1 1 ;
 2 2 2 2 2 2 2 2 1 1 ;
 2 2 2 2 2 2 2 2 1 1 ;
 2 2 2 1 1 1 1 1 1 1 ;
 2 2 2 1 1 1 1 1 1 1 ];
%��������� 9
%������� �� ���������� ������� � �������

p6 = [];
p3 = [];
p9 = [];

for i = 1:n
for j = 1:m
if X6(i,j) == 1
    p6 = [p6,-1];
end;
if X6(i,j) == 2
    p6 = [p6,1];
end;
end;
end;

for i = 1:n
for j = 1:m
if X3(i,j) == 1
    p3 = [p3,-1];
end;
if X3(i,j) == 2
    p3 = [p3,1];
end;
end;
end;

for i = 1:n
for j = 1:m
if X9(i,j) == 1
    p9 = [p9,-1];
end;
if X9(i,j) == 2
    p9 = [p9,1];
end;
end;
end;

IW=[p6;p3;p9];
b1 = [m*n;m*n;m*n];
epsilon=0.5;
for i=1:3
 for j=1:3
 LW(i,j)=-epsilon;
 if i==j
 LW(i,j)=1;
 end
 end
end
T = [p6;p3;p9]';
a1=IW*T+[b1,b1,b1];
net = newhop(a1);
net.layers{1}.transferFcn='poslin';
display(net);
view(net);
net.LW{1,1}=LW;
net.b{1}=[0;0;0];
Ai = IW*T+[b1,b1,b1];
Y = sim(net,3,[],Ai);
Y;
Y=Y(:,1);
[argvalue, argmax] = max(Y);
if (argmax == 1)
 X=X6;
end
if (argmax == 2)
 X=X3;
end
if (argmax == 3)
 X=X9;
end
figure;
image(X);
title('Output Image 6')
colormap(map);
axis off;
axis image;
% p = rand(n,m); %������� ����
% X61=noise(X6,n,m,p,0.2);
% X31=noise(X3,n,m,p,0.2);
% X91=noise(X9,n,m,p,0.2);
% figure;
% image(X31);
% title('Input Image 3')
% colormap(map);
% axis off;
% axis image;
% p61 = matrix_to_vector(X6,n,m);
% p31 = matrix_to_vector(X3,n,m);
% p91 = matrix_to_vector(X9,n,m);
% Ai = IW*[p61; p31; p91]'+[b1,b1,b1];
% [Y1] = sim(net,3,[],Ai);
% Y1;
% Y=Y1(:,2);
% [argvalue, argmax] = max(Y);
% if (argmax == 1)
%  X=X6;
% end
% if (argmax == 2)
%  X=X3;
% end
% if (argmax == 3)
%  X=X9;
% end
% figure;
% image(X);
% title('Output Image 3')
% colormap(map);
% axis off;
% axis image;
% X91=noise(X9,n,m,p,0.3);
% p91 = matrix_to_vector(X91,n,m);
% figure;
% image(X91);
% title('Input Image 9')
% colormap(map);
% axis off;
% 14
% axis image;
% Ai = IW*[p61; p31; p91]'+[b1,b1,b1];
% [Y1] = sim(net,3,[],Ai);
% Y1;
% Y=Y1(:,3);
% [argvalue, argmax] = max(Y);
% if (argmax == 1)
%  X=X6;
% end
% if (argmax == 2)
%  X=X3;
% end
% if (argmax == 3)
%  X=X9;
% end
% figure;
% image(X);
% title('Output Image 9')
% colormap(map);
% axis off;
% axis image;

%�������

% function (T) = matrix_to_vector(X,n,m)
%     for i=1:n
%         for j=1:m
%             if (X(i,j)==2)
%                 T(i,j)=1;
%             else
%                 T(i,j)=-1;
%             end;
%         end;
%     end;
% T = reshape(T',1,[]);
% end;

% function X = noise(X,n,m,p,p0)
%  for i=1:n
%  for j=1:m
%  if (p(i,j)<=p0)
%  if (X(i,j)==2)
%  X(i,j)=1;
%  else
%  X(i,j)=2;
%  end
%  end
%  end
%  end
% end