clear all;
close all;

%3 6 0

n = 12;
m = 10;

map = [0, 0, 0; 1, 1, 1];

X3=[2 2 1 1 1 1 1 1 2 2;
    2 2 1 1 1 1 1 1 1 2;
    2 2 2 2 2 2 2 1 1 2;
    2 2 2 2 2 2 2 1 1 2;
    2 2 2 2 2 2 2 1 1 2;
    2 2 2 2 1 1 1 1 2 2;
    2 2 2 2 1 1 1 1 2 2;
    2 2 2 2 2 2 2 1 1 2;
    2 2 2 2 2 2 2 1 1 2;
    2 2 2 2 2 2 2 1 1 2;
    2 2 1 1 1 1 1 1 1 2;
    2 2 1 1 1 1 1 1 2 2];

X6=[1 1 1 1 1 1 1 1 2 2;
    1 1 1 1 1 1 1 1 2 2;
    1 1 2 2 2 2 2 2 2 2;
    1 1 2 2 2 2 2 2 2 2;
    1 1 1 1 1 1 1 1 2 2;
    1 1 1 1 1 1 1 1 2 2;
    1 1 2 2 2 2 1 1 2 2;
    1 1 2 2 2 2 1 1 2 2;
    1 1 2 2 2 2 1 1 2 2;
    1 1 2 2 2 2 1 1 2 2;
    1 1 1 1 1 1 1 1 2 2;
    1 1 1 1 1 1 1 1 2 2];

X0=[2 2 2 2 2 2 2 2 2 2;
    2 2 2 1 1 1 1 2 2 2;
    2 2 1 1 1 1 1 1 2 2;
    2 1 1 1 2 2 1 1 1 2;
    2 1 1 1 2 2 1 1 1 2;
    2 1 1 1 2 2 1 1 1 2;
    2 1 1 1 2 2 1 1 1 2;
    2 1 1 1 2 2 1 1 1 2;
    2 1 1 1 2 2 1 1 1 2;
    2 2 1 1 1 1 1 1 2 2;
    2 2 2 1 1 1 1 2 2 2;
    2 2 2 2 2 2 2 2 2 2];

figure;
map = [0, 0, 0; 1, 1, 1];
image(X3); colormap(map)
axis off
axis image

figure;
map = [0, 0, 0; 1, 1, 1];
image(X6); colormap(map)
axis off
axis image

figure;
map = [0, 0, 0; 1, 1, 1];
image(X0); colormap(map)
axis off
axis image

p3 = [];
p6 = [];
p0 = [];

for i = 1:n
for j = 1:m
if X3(i,j) == 1
    p3 = [p3,-1];
end;
if X3(i,j) == 2
    p3 = [p3,1];
end;
end;
end;

for i = 1:n
for j = 1:m
if X6(i,j) == 1
    p6 = [p6,-1];
end;
if X6(i,j) == 2
    p6 = [p6,1];
end;
end;
end;

for i = 1:n
for j = 1:m
if X0(i,j) == 1
    p0 = [p0,-1];
end;
if X0(i,j) == 2
    p0 = [p0,1];
end;
end;
end;

T = [p3; p6; p0]';

net.trainParam.epochs=600;
net = newhop(T);

% net.trainFcn = '';
% net.sampleTime = 10;
% net.numFeedbackDelays = 5;

display(net);
view(net);

Ai = T;
Y = sim(net,3,[],Ai);
Y;

res_3 = zeros(n,m);
for i=1:n
    for j=1:m
        if Y((i-1)*10 + j,1) == -1
            res_3(i,j) = 1;
        end;
        if Y((i-1)*10 + j,1) == 1
            res_3(i,j) = 2;
        end;
    end;
end;

res_6 = zeros(n,m);
for i=1:n
    for j=1:m
        if Y((i-1)*10 + j,2) == -1
            res_6(i,j) = 1;
        end;
        if Y((i-1)*10 + j,2) == 1
            res_6(i,j) = 2;
        end;
    end;
end;

res_0 = zeros(n,m);
for i=1:n
    for j=1:m
        if Y((i-1)*10 + j,3) == -1
            res_0(i,j) = 1;
        end;
        if Y((i-1)*10 + j,3) == 1
            res_0(i,j) = 2;
        end;
    end;
end;
        
figure;
image(res_6); colormap(map);
axis off;
axis image;


X3_n = X3;
p_rand = rand(12,10);

for i=1:n
    for j=1:m
        if p_rand(i,j) < 0.2
            if X3_n(i,j) == 2
                X3_n(i,j) = 1;
            else
                X3_n(i,j) = 2;
            end;
        end;
    end;
end;

X6_n = X6;

for i=1:n
    for j=1:m
        if p_rand(i,j) < 0.2
            if X6_n(i,j) == 2
                X6_n(i,j) = 1;
            else
                X6_n(i,j) = 2;
            end;
        end;
    end;
end;

X0_n = X0;

for i=1:n
    for j=1:m
        if p_rand(i,j) < 0.3
            if X0_n(i,j) == 2
                X0_n(i,j) = 1;
            else
                X0_n(i,j) = 2;
            end;
        end;
    end;
end;

p3_n = [];
p6_n = [];
p0_n = [];

for i = 1:n
for j = 1:m
if X3_n(i,j) == 1
    p3_n = [p3_n,-1];
end;
if X3_n(i,j) == 2
    p3_n = [p3_n,1];
end;
end;
end;

for i = 1:n
for j = 1:m
if X6_n(i,j) == 1
    p6_n = [p6_n,-1];
end;
if X6_n(i,j) == 2
    p6_n = [p6_n,1];
end;
end;
end;

for i = 1:n
for j = 1:m
if X0_n(i,j) == 1
    p0_n = [p0_n,-1];
end;
if X0_n(i,j) == 2
    p0_n = [p0_n,1];
end;
end;
end;


Ai = [p3_n;p6_n;p0_n]';
Y = sim(net,3,[],Ai);
Y = sim(net,3,[],Y);
Y = sim(net,3,[],Y);
Y = sim(net,3,[],Y);
Y = sim(net,3,[],Y);
Y = sim(net,3,[],Y);
Y = sim(net,3,[],Y);

res_3_n = zeros(n,m);
for i=1:n
    for j=1:m
        if Y((i-1)*10 + j,1) == -1
            res_3_n(i,j) = 1;
        end;
        if Y((i-1)*10 + j,1) == 1
            res_3_n(i,j) = 2;
        end;
    end;
end;

res_6_n = zeros(n,m);
for i=1:n
    for j=1:m
        if Y((i-1)*10 + j,2) == -1
            res_6_n(i,j) = 1;
        end;
        if Y((i-1)*10 + j,2) == 1
            res_6_n(i,j) = 2;
        end;
    end;
end;

res_0_n = zeros(n,m);
for i=1:n
    for j=1:m
        if Y((i-1)*10 + j,3) == -1
            res_0_n(i,j) = 1;
        end;
        if Y((i-1)*10 + j,3) == 1
            res_0_n(i,j) = 2;
        end;
    end;
end;
        
% figure;
% image(res_3_n); colormap(map);
% axis off;
% axis image;

figure;
image(X6_n); colormap(map);
axis off;
axis image;

figure;
image(res_6_n); colormap(map);
axis off;
axis image;

figure;
image(X0_n); colormap(map);
axis off;
axis image;

figure;
image(res_0_n); colormap(map);
axis off;
axis image;