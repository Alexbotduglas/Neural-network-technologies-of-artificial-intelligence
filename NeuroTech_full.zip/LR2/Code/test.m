clear all;
close all;

x = @(t)

%net = newp([-5 5; -5 5], [0 1]);

%display(net);
%view(net)