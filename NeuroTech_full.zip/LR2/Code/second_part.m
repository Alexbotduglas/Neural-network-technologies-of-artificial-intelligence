clear all;
close all;

x1 = @(t) sin(-sin(t).*t.*t + t);
x2 = @(t) cos(-5*t.*t + 10*t - 5);
y = @(t) (1/8)*cos(-5*t.*t + 10*t);

t1=0.5:0.01:4;
t2=0:0.01:2.5;

P = x1(t1);
plot(t1, P, '.-'); grid;

for i=1:2
    PI(i) = P(i);
end;

for i=1:size(P,2)-3
    PM(i) = P(i+2);
end;

for i=1:size(P,2)-3
    PM1(i) = P(i+3);
end;

lr = maxlinlr(P, 'bias');

nnet = newlin([-1,1], [-1,1], [0 1 2], lr);

display(nnet);
view(nnet);

nnet.inputweights{1,1}.initFcn = 'rands';
net.biases{1}.initFcn = 'rands';

nnet = init(nnet);

IW = nnet.IW{1,1}
b = nnet.b{1}
M1 = sqrt(mse(PM - nnet(PM)))

P = con2seq(P);

Y = sim(nnet, P);

Y = seq2con(Y); Y = Y{1};
P = seq2con(P); P = P{1};
E = Y - P;

%figure;
%subplot(211)
%plot(t1,P,'b',t1,Y,'r--'); grid;
%subplot(212)
%plot(t1,E,'g'); grid;

PI = con2seq(PI);
PM = con2seq(PM);
PM1 = con2seq(PM1);
P = con2seq(P);

nnet.trainParam.goal=1E-6;
nnet.trainParam.epochs=600;
nnet=train(nnet, PM, PM1, PI)

%Y = nnet(P);
Y = sim(nnet, P);
Y = seq2con(Y); Y = Y{1};
P = seq2con(P); P = P{1};
E = Y - P;

M1 = sqrt(mse(Y-P))
MAE1 = mae(E, Y, P)
MAPE1= mean((abs(Y-P))./P)
R2 = 1 - sum((P - Y).^2)/sum((P - mean(Y)).^2)
min_ae = min(abs(P - Y))
max_ae = max(abs(P - Y))
SKO1 = M1/((max(Y) - min(Y)))

IW = nnet.IW{1,1}
b = nnet.b{1}

E_1 = 0; E_2 = 0; E_3 = 0; E_4 = 0; E_5 = 0;
for i=1:length(E)
    if abs(E(i)) < 0.05
        E_1 = E_1 + 1;
    end;
    if(abs(E(i))>=0.05)&&(abs(E(i))<0.1)
        E_2 = E_2 + 1;
    end;
    if(abs(E(i))>=0.1&&(abs(E(i))<0.2))
        E_3 = E_3 + 1;
    end;
    if(abs(E(i))>=0.2&&(abs(E(i))<0.3))
        E_4 = E_4 + 1;
    end;
    if(abs(E(i))>=0.3)
        E_5 = E_5 + 1;
    end;
end;

E_1 = E_1/length(E)
E_2 = E_2/length(E)
E_3 = E_3/length(E)
E_4 = E_4/length(E)
E_5 = E_5/length(E)

%figure;
%subplot(211)
%plot(t1,P,'b',t1,Y,'r--'); grid;
%subplot(212)
%plot(t1,E,'g'); grid;


t3=0.51:0.01:4.01;
X1 = x1(t3);
E = Y - X1;
M2 = sqrt(mse(Y-X1))

%figure;
%subplot(211)
%plot(t3,X,'b',t3,Y,'r--'); grid;
%subplot(212)
%plot(t3,E,'g'); grid;


t4=0.5:0.01:4.5;
P1 = x1(t4);
P2 = con2seq(P1);
Y1 = sim(nnet, P2);

Y1 = seq2con(Y1); Y1 = Y1{1};

t5 = 0.51:0.01:4.51;
X1 = x1(t5);

E1 = X1 - Y1;
M3 = sqrt(mse(Y1-X1))
MAE3 = mae(E1, Y1, X1)
MAPE3= mean((abs(Y1-X1))./X1)
R2 = 1 - sum((X1 - Y1).^2)/sum((X1 - mean(Y1)).^2)
min_ae = min(abs(X1 - Y1))
max_ae = max(abs(X1 - Y1))
SKO1 = M3/((max(Y1) - min(Y1)))

IW = nnet.IW{1,1}
b = nnet.b{1}

for i=1:length(E)
    if abs(E(i)) < 0.05
        E_1 = E_1 + 1;
    end;
    if(abs(E(i))>=0.05)&&(abs(E(i))<0.1)
        E_2 = E_2 + 1;
    end;
    if(abs(E(i))>=0.1&&(abs(E(i))<0.2))
        E_3 = E_3 + 1;
    end;
    if(abs(E(i))>=0.2&&(abs(E(i))<0.3))
        E_4 = E_4 + 1;
    end;
    if(abs(E(i))>=0.3)
        E_5 = E_5 + 1;
    end;
end;

E_1 = E_1/length(E1)
E_2 = E_2/length(E1)
E_3 = E_3/length(E1)
E_4 = E_4/length(E1)
E_5 = E_5/length(E1)

figure;
subplot(211)
plot(t4,P1,'b',t4,Y1,'r--'); grid;

subplot(212)
plot(t5,E1,'g'); grid;

IW = nnet.IW{1,1}
b = nnet.b{1}
