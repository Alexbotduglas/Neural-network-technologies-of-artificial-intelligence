clear all;
close all;

x1 = @(t) sin(-sin(t).*t.*t + t);
x2 = @(t) cos(t.*t + 10*t - 5);
y = @(t) (1/8)*cos(t.*t + 10*t);

%x1 = @(t) sin(t.*t);
%x2 = @(t) sin((2*pi*t)./3);
%y = @(t) 0.2*sin((2*pi*t)./3 + pi/2);

t1=0.5:0.01:4;
t2=0:0.025:5.5;

% t1 = 0:0.025:5;
% t2 = 0:0.025:5;

P = x2(t2);
T = y(t2);

plot(t2,P,'.-',t2,T,'-'); grid;

P1 = zeros(4, size(P,1));

for i=1:3
    P2(i) = P(i);
end;

for i=1:size(P,2)
    P2(i+3) = P(i);
end;

for i=1:4
    P3(i, 1:size(P,2)) = P2(i:size(P,2)+ i - 1);
end;

T = con2seq(T);
P3 = con2seq(P3);

nnet = newlind(P3, T)

Y = sim(nnet,P3);

Y = seq2con(Y); Y = Y{1};
T = seq2con(T); T = T{1};

E = T - Y;
M3 = sqrt(mse(E))
MAE3 = mae(E, Y, T)
MAPE3= mean(abs((abs(Y-T))./T))
IW = nnet.IW
b = nnet.b
R2 = 1 - sum((T - Y).^2)/sum((T - mean(Y)).^2)
min_ae = min(abs(Y - T))
max_ae = max(abs(Y - T))
SKO1 = M3/((max(Y) - min(Y)))

E_1 = 0; E_2 = 0; E_3 = 0; E_4 = 0; E_5 = 0;
for i=1:length(E)
    if abs(E(i)) < 0.05
        E_1 = E_1 + 1;
    end;
    if(abs(E(i))>=0.05)&&(abs(E(i))<0.1)
        E_2 = E_2 + 1;
    end;
    if(abs(E(i))>=0.1&&(abs(E(i))<0.2))
        E_3 = E_3 + 1;
    end;
    if(abs(E(i))>=0.2&&(abs(E(i))<0.3))
        E_4 = E_4 + 1;
    end;
    if(abs(E(i))>=0.3)
        E_5 = E_5 + 1;
    end;
end;

E_1 = E_1/length(E)
E_2 = E_2/length(E)
E_3 = E_3/length(E)
E_4 = E_4/length(E)
E_5 = E_5/length(E)

figure;
plot(t2, T, 'b', t2, Y, 'r--'); grid;