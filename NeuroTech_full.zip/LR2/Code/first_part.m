clear all;
close all;

x1 = @(t) sin(-sin(t).*t.*t + t);
x2 = @(t) cos(-5*t.*t + 10*t - 5);
y = @(t) (1/8)*cos(-5*t.*t + 10*t);

t1=0.5:0.01:4;
t2=0:0.01:2.5;

P = x1(t1);
plot(t1, P, '.-'); grid;

for i=1:5
    PI(i) = P(i);
end;

for i=1:size(P,2)-5
    PM(i) = P(i+5);
end;

nnet = newlin([-1,1], 1, [1 2 3 4 5], 0.01);

display(nnet);
view(nnet);

nnet.inputweights{1,1}.initFcn = 'rands';
net.biases{1}.initFcn = 'rands';

nnet = init(nnet);

IW = nnet.IW{1,1}
b = nnet.b{1}
M1 = sqrt(mse(PM - nnet(PM)))

PI = con2seq(PI);
PM = con2seq(PM);
P = con2seq(P);

%Y = sim(nnet, P, PI);
%Y = seq2con(Y); Y = Y{1};
%P = seq2con(P); P = P{1};
%E = Y - P;

%figure;

%subplot(211)
%plot(t1,P,'b',t1,Y,'r--'); grid;

%subplot(212)
%plot(t1,E,'g'); grid;

nnet.adaptParam.passes = 50;
[nnet, Y, E] = adapt(nnet, PM, PM, PI);

Y = sim(nnet, P, PI);
Y = seq2con(Y); Y = Y{1};
P = seq2con(P); P = P{1};
E = Y - P;

M2 = sqrt(mse(Y-P))

figure;

subplot(211)
plot(t1,P,'b',t1,Y,'r--'); grid;

subplot(212)
plot(t1,E,'g'); grid;

IW = nnet.IW{1,1}
b = nnet.b{1}

%net = newp([-5 5; -5 5], [0 1]);

%display(net);
%view(net)