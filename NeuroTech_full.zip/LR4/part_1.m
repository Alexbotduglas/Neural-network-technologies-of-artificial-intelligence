clear all;
close all;

t=-1*pi:0.025:pi;

a1 = 0.40;
b1 = 0.15;
alpha1 = pi/6;
x01 = 0.1;
y01 = -0.15;

a2 = 0.70;
b2 = 0.50;
alpha2 = pi/3;
x02 = 0;
y02 = 0;

p = 1;
alpha3 = pi/2;
x0 = -0.8;
y0 = 0;

x1 = @(t) x01 + a1*cos(t)*cos(alpha1) + b1*sin(t)*sin(alpha1);
y1 = @(t) y01 - a1*cos(t)*sin(alpha1) + b1*sin(t)*cos(alpha1);
x2 = @(t) x02 + a2*cos(t)*cos(alpha2) + b2*sin(t)*sin(alpha2);
y2 = @(t) y02 - a2*cos(t)*sin(alpha2) + b2*sin(t)*cos(alpha2);
x3 = @(t) (t.*t)/(2*p);
y3 = @(t) t;

x1 = x1(t);
y1 = y1(t);
x2 = x2(t);
y2 = y2(t);
x3 = x3(t);
y3 = y3(t);

figure;

gr=plot(x1,y1,x2,y2,x3,y3);
set(gr(1), 'LineStyle', '-', 'Color', 'r');
set(gr(2), 'LineStyle', '-', 'Color', 'g');
set(gr(3), 'LineStyle', '-', 'Color', 'b');

k = size(t, 2);

% p1 = randperm(k, 60);
% p2 = randperm(k, 100);
% p3 = randperm(k, 120);

p_1 = randperm(252)';
p_2 = randperm(252)';
p_3 = randperm(252)';

for i=1:60
    p1(i)= p_1(i);
end;
for i=1:100
    p2(i)= p_2(i);
end;
for i=1:120
    p3(i)= p_3(i);
end;

p1 = p1';
p2 = p2';
p3 = p3';

X1 = x1(p1);
X2 = x2(p2);
X3 = x3(p3);
Y1 = y1(p1);
Y2 = y2(p2);
Y3 = y3(p3);

figure;
gr = plot(x1,y1,x2,y2,x3,y3,X1,Y1,X2,Y2,X3,Y3);
set(gr(1), 'LineStyle', '-', 'Color', 'r');
set(gr(2), 'LineStyle', '-', 'Color', 'g');
set(gr(3), 'LineStyle', '-', 'Color', 'b');
set(gr(4), 'Marker', 'o', 'Color', 'r', 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'r', 'MarkerSize', 7, 'LineStyle', 'none');
set(gr(5), 'Marker', 'o', 'Color', 'g', 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'g', 'MarkerSize', 7, 'LineStyle', 'none');
set(gr(6), 'Marker', 'o', 'Color', 'b', 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'b', 'MarkerSize', 7, 'LineStyle', 'none');
title('�������� ��������� �����')


[trainInd1, valInd1, testInd1] = dividerand(60, 0.8, 0, 0.2);
[trainInd2, valInd2, testInd2] = dividerand(100, 0.8, 0, 0.2);
[trainInd3, valInd3, testInd3] = dividerand(120, 0.8, 0, 0.2);

train1X = X1(trainInd1);
train1Y = Y1(trainInd1);
train2X = X2(trainInd2);
train2Y = Y2(trainInd2);
train3X = X3(trainInd3);
train3Y = Y3(trainInd3);

for i=1:size(train1X,2) %�������� �������
train1t(i) = 1;
end

for i=1:size(train2X,2)
train2t(i) = 2;
end

for i=1:size(train3X,2)
train3t(i) = 3;
end

test1X = X1(testInd1);
test1Y = Y1(testInd1);
test2X = X2(testInd2);
test2Y = Y2(testInd2);
test3X = X3(testInd3);
test3Y = Y3(testInd3);

for i=1:size(test1X,2)
test1t(i) = 1;
end

for i=1:size(test2X,2)
test2t(i) = 2;
end

for i=1:size(test3X,2)
test3t(i) = 3;
end

figure;
gr = plot(x1, y1, x2, y2, x3, y3, train1X, train1Y, train2X, train2Y, train3X, train3Y, test1X, test1Y, test2X, test2Y, test3X, test3Y);
axis([-1.2 1.2 -1.2 1.2]);
set(gr(1), 'LineStyle', '-', 'Color', 'r', 'LineWidth', 2);
set(gr(2), 'LineStyle', '-', 'Color', 'g', 'LineWidth', 2);
set(gr(3), 'LineStyle', '-', 'Color', 'b', 'LineWidth', 2);
set(gr(4), 'Marker', 'o', 'Color', 'r', 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'r', 'MarkerSize', 7, 'LineStyle', 'none');
set(gr(5), 'Marker', 'o', 'Color', 'g', 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'g', 'MarkerSize', 7, 'LineStyle', 'none');
set(gr(6), 'Marker', 'o', 'Color', 'b', 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'b', 'MarkerSize', 7, 'LineStyle', 'none');
set(gr(7), 'Marker', 'o', 'Color', 'r', 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'c', 'MarkerSize', 7, 'LineStyle', 'none');
set(gr(8), 'Marker', 'o', 'Color', 'g', 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'c', 'MarkerSize', 7, 'LineStyle', 'none');
set(gr(9), 'Marker', 'o', 'Color', 'b', 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'c', 'MarkerSize', 7, 'LineStyle', 'none');
title('��������� � �������� ������ �����');

trainX=[train1X,train2X,train3X];
trainY=[train1Y,train2Y,train3Y];
testX=[test1X,test2X,test3X];
testY=[test1Y,test2Y,test3Y];
traint=[train1t,train2t,train3t];
testt=[test1t,test2t,test3t];

T = ind2vec(traint);

spread = 0.05;
net = newpnn([trainX; trainY], T, spread);

display(net);
view(net);

Y = sim(net, [trainX; trainY]);
Yc = vec2ind(Y);
Z = abs(Yc - traint);
N = size(traint, 2);

p = 0;
for i = 1:N
if not(Z(i) == 0)
p = p + 1;
end;
end;

probtrain = ((N - p) / N) * 100;

Yy = sim(net, [testX; testY]);
Yc1 = vec2ind(Yy);
Z1 = abs(Yc1 - testt);
N1 = size(testt, 2);

p = 0;
for i = 1:N1
if not(Z1(i) == 0)
p = p + 1;
end;
end;

probtest = ((N1 - p) / N1) * 100;

xs = -1.2:0.025:1.2;
ys = -1.2:0.025:1.2;

for i = 1:size(xs, 2);
for j = 1:size(xs, 2);
Xs(i,j) = xs(i);
Ys(i,j) = ys(j);
end;
end;

X = [];
for i = 1:size(xs, 2);
X = [X, Xs(i, :)];
end;

Y = [];
for i = 1:size(xs, 2);
Y = [Y, Ys(i, :)];
end;

Pp = [X; Y];
Zz = sim(net, Pp);
Zz = vec2ind(Zz);

xa1 = [];
ya1 = [];

for i = 1:size(Zz, 2)
if Zz(i) == 1
xa1 = [xa1, X(i)];
ya1 = [ya1, Y(i)];
end;
end;

xa2 = [];
ya2 = [];

for i = 1:size(Zz, 2)
if Zz(i) == 2
xa2 = [xa2, X(i)];
ya2 = [ya2, Y(i)];
end;
end;

xa3 = [];
ya3 = [];

for i = 1:size(Zz, 2)
if Zz(i) == 3
xa3 = [xa3, X(i)];
ya3 = [ya3, Y(i)];
end;
end;

figure;
gr2=plot(xa1,ya1,xa2,ya2,xa3,ya3,x1,y1,x2,y2,x3,y3);
set(gr2(1), 'Marker', 'o', 'Color', 'r','MarkerSize', 7, 'LineStyle', 'none');
set(gr2(2), 'Marker', 'o', 'Color', 'g','MarkerSize', 7, 'LineStyle', 'none');
set(gr2(3), 'Marker', 'o', 'Color', 'b','MarkerSize', 7, 'LineStyle', 'none');
set(gr2(4), 'LineStyle', '-', 'Color', 'k', 'LineWidth', 2);
set(gr2(5), 'LineStyle', '-', 'Color', 'k', 'LineWidth', 2);
set(gr2(6), 'LineStyle', '-', 'Color', 'k', 'LineWidth', 2);
title('�������������')