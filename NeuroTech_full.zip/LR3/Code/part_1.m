clear all;
close all;

t=-1*pi:0.025:pi;

a1 = 0.40;
b1 = 0.15;
alpha1 = pi/6;
x01 = 0.1;
y01 = -0.15;

a2 = 0.70;
b2 = 0.50;
alpha2 = pi/3;
x02 = 0;
y02 = 0;

p = 1;
alpha3 = pi/2;
x0 = -0.8;
y0 = 0;

x1 = @(t) x01 + a1*cos(t)*cos(alpha1) + b1*sin(t)*sin(alpha1);
y1 = @(t) y01 - a1*cos(t)*sin(alpha1) + b1*sin(t)*cos(alpha1);
x2 = @(t) x02 + a2*cos(t)*cos(alpha2) + b2*sin(t)*sin(alpha2);
y2 = @(t) y02 - a2*cos(t)*sin(alpha2) + b2*sin(t)*cos(alpha2);
x3 = @(t) (t.*t)/(2*p);
y3 = @(t) t;

X1 = x1(t);
Y1 = y1(t);
X2 = x2(t);
Y2 = y2(t);
X3 = x3(t);
Y3 = y3(t);

figure;
plot(X1,Y1,'r',X2,Y2,'g',X3,Y3,'b'); grid;
hold on;

%�������� ��������� ����� �� ������
k = size(t,2);
% p1 = (rand(60,1))*2*pi;
% p2 = (rand(100,1))*2*pi;
% p3 = (rand(120,1))*2*pi;

p_1 = randperm(252)';
p_2 = randperm(252)';
p_3 = randperm(252)';

for i=1:60
    p1(i)= p_1(i);
end;
for i=1:100
    p2(i)= p_2(i);
end;
for i=1:120
    p3(i)= p_3(i);
end;

p1 = p1';
p2 = p2';
p3 = p3';

X1_ = X1(p1)';
X2_ = X2(p2)';
X3_ = X3(p3)';

Y1_ = Y1(p1)';
Y2_ = Y2(p2)';
Y3_ = Y3(p3)';

scatter(X1_, Y1_, 'r'); grid; hold on;
scatter(X2_, Y2_, 'g'); grid; hold on;
scatter(X3_, Y3_, 'b'); grid; hold on;

%������� train, val � test ��������
[train1i,val1i,test1i] = dividerand(60, 0.7, 0.2, 0.1);
[train2i,val2i,test2i] = dividerand(100, 0.7, 0.2, 0.1);
[train3i,val3i,test3i] = dividerand(120, 0.7, 0.2, 0.1);

%train, val, test
train1X = X1_(train1i)';
train1Y = Y1_(train1i)';
train2X = X2_(train2i)';
train2Y = Y2_(train2i)';
train3X = X3_(train3i)';
train3Y = Y3_(train3i)';

for i=1:size(train1X, 2)
    train1t(i,:) = [1,0,0];
end;

for i=1:size(train2X, 2)
    train2t(i,:) = [0,1,0];
end;

for i=1:size(train3X, 2)
    train3t(i,:) = [0,0,1];
end;

val1X = X1_(val1i)';
val1Y = Y1_(val1i)';
val2X = X2_(val2i)';
val2Y = Y2_(val2i)';
val3X = X3_(val3i)';
val3Y = Y3_(val3i)';

for i=1:size(val1X, 2)
    val1t(i,:) = [1,0,0];
end;

for i=1:size(val2X, 2)
    val2t(i,:) = [0,1,0];
end;

for i=1:size(val3X, 2)
    val3t(i,:) = [0,0,1];
end;

test1X = X1_(test1i)';
test1Y = Y1_(test1i)';
test2X = X2_(test2i)';
test2Y = Y2_(test2i)';
test3X = X3_(test3i)';
test3Y = Y3_(test3i)';

for i=1:size(test1X, 2)
    test1t(i,:) = [1,0,0];
end;

for i=1:size(test2X, 2)
    test2t(i,:) = [0,1,0];
end;

for i=1:size(test3X, 2)
    test3t(i,:) = [0,0,1];
end;

figure;
f2 = plot(X1,Y1,X2,Y2,X3,Y3,train1X,train1Y,train2X,train2Y,train3X,train3Y,val1X,val1Y,val2X,val2Y,val3X,val3Y,test1X,test1Y,test2X,test2Y,test3X,test3Y);
axis([-1.2 1.2 -1.2 1.2]);
set(f2(1),'LineStyle','-','Color','r');
set(f2(2),'LineStyle','-','Color','g');
set(f2(3),'LineStyle','-','Color','b');
set(f2(4),'LineStyle','none','Marker','o','Color','r', 'MarkerEdgeColor', 'k','MarkerFaceColor', 'r', 'MarkerSize', 7);
set(f2(5),'LineStyle','none','Marker','o','Color','g', 'MarkerEdgeColor', 'k','MarkerFaceColor', 'g', 'MarkerSize', 7);
set(f2(6),'LineStyle','none','Marker','o','Color','b', 'MarkerEdgeColor', 'k','MarkerFaceColor', 'b', 'MarkerSize', 7);
set(f2(7),'LineStyle','none','Marker','V','Color','r', 'MarkerEdgeColor', 'k','MarkerFaceColor', 'c', 'MarkerSize', 7);
set(f2(8),'LineStyle','none','Marker','V','Color','g', 'MarkerEdgeColor', 'k','MarkerFaceColor', 'c', 'MarkerSize', 7);
set(f2(9),'LineStyle','none','Marker','V','Color','b', 'MarkerEdgeColor', 'k','MarkerFaceColor', 'c', 'MarkerSize', 7);
set(f2(10),'LineStyle','none','Marker','s','Color','r', 'MarkerEdgeColor', 'k','MarkerFaceColor', 'c', 'MarkerSize', 7);
set(f2(11),'LineStyle','none','Marker','s','Color','g', 'MarkerEdgeColor', 'k','MarkerFaceColor', 'c', 'MarkerSize', 7);
set(f2(12),'LineStyle','none','Marker','s','Color','b', 'MarkerEdgeColor', 'k','MarkerFaceColor', 'c', 'MarkerSize', 7);

trainX = [train1X, train2X, train3X];
trainY = [train1Y, train2Y, train3Y];

valX = [val1X, val2X, val3X];
valY = [val1Y, val2Y, val3Y];

testX = [test1X, test2X, test3X];
testY = [test1Y, test2Y, test3Y];

net = feedforwardnet(20);

net = configure(net, [-1.2, 1.2; -1.2, 1.2],[0,1; 0,1; 0,1]);
net.layers{2}.transferFcn = 'tansig';

net.trainFcn='trainrp';
net.divideFcn = 'divideind';

display(net);

init(net);
net.trainParam.epochs = 1500;
net.trainParam.max_fail = 1500;
net.trainParam.goal = 1E-5;

net.divideParam.trainInd = 1:size(trainX,2);
net.divideParam.valInd = size(trainX,2)+1:size(valX,2) + size(trainX,2);
net.divideParam.testInd = size(valX,2)+size(trainX,2)+1:size(testX,2) + size(trainX,2) + size(valX,2);

X = [trainX, valX, testX];
Y = [trainY, valY, testY];

P = [X',Y']';
T = [train1t',train2t',train3t',val1t',val2t',val3t',test1t',test2t',test3t'];

% P = con2seq(P);
% T = con2seq(T);

% dividetest_tr = P(1:size(trainX,2))
% dividetest_va = P(size(trainX,2)+1:size(valX,2) + size(trainX,2))

% for i=1:size(P,1)
%     P1(i) = column(P(i,1),P(i,2));
% end;
% 
% for i=1:size(P,1)
%     T1(i) = T(i,:);
% end;

IW_1 = net.IW;
b_1 = net.b;

net = train(net,P,T);

IW_2 = net.IW;
b_2 = net.b;

trx = [trainX;trainY];
tr = sim(net,trx);

for i=1:3
    for j=1:size(trx,2)
        if tr(i,j)<0.5
            a(i,j)=0;
        else
            a(i,j)=1;
        end;
    end;
end;

tt = [train1t; train2t; train3t]';
N = 0;

for i = 1:size(trx,2)
    if a(:,i)==tt(:,i)
        N=N+1;
    end;
end;

display(N);

vlx = [valX;valY];
vl = sim(net,vlx);

for i=1:3
    for j=1:size(vlx,2)
        if vl(i,j) < 0.5
            b(i,j)=0;
        else
            b(i,j)=1;
        end;
    end;
end;

vv = [val1t;val2t;val3t]';
K = 0;

for i=1:size(vlx,2)
    if b(:,i)==vv(:,i)
        K=K+1;
    end;
end;

display(K);

tsx = [testX;testY];
ts = sim(net,tsx);

for i=1:3
    for j=1:size(tsx,2)
        if ts(i,j)<0.5
            c(i,j)=0;
        else
            c(i,j)=1;
        end;
    end;
end;

xx = [test1t;test2t;test3t]';
M = 0;

for i=1:size(tsx,2)
    if c(:,i)==xx(:,i)
        M=M+1;
    end;
end;

display(M);

xs = -1.2:0.025:1.2;
ys = -1.2:0.025:1.2;

for i=1:size(xs,2)
    for j=1:size(xs,2)
        Xs(i,j)=xs(i);
        Ys(i,j)=ys(j);
    end;
end;

X = [];
for i=1:size(xs,2)
    X=[X,Xs(i,:)];
end;

Y=[];
for i=1:size(xs,2)
    Y=[Y,Ys(i,:)];
end;

Pp=[X;Y];

Zz=sim(net,Pp);

for i=1:size(Zz,1)
    for j=1:size(Zz,2)
        if Zz(i,j)<0.5
            Oo(i,j)=0;
        else
            Oo(i,j)=1;
        end;
    end;
end;

xa1=[];
ya1=[];

for i=1:size(Zz,2)
    if Oo(:,i)'==[1,0,0]
        xa1=[xa1,X(i)];
        ya1=[ya1,Y(i)];
    end;
end;

xa2=[];
ya2=[];

for i=1:size(Zz,2)
    if Oo(:,i)'==[0,1,0]
        xa2=[xa2,X(i)];
        ya2=[ya2,Y(i)];
    end;
end;

xa3=[];
ya3=[];

for i=1:size(Zz,2)
    if Oo(:,i)'==[0,0,1]
        xa3=[xa3,X(i)];
        ya3=[ya3,Y(i)];
    end;
end;

figure;
gr2=plot(xa1,ya1,xa2,ya2,xa3,ya3,X1,Y1,X2,Y2,X3,Y3);
axis([-1.2 1.2 -1.2 1.2]);
set(gr2(1),'LineStyle','none','Marker','o','Color','r','MarkerFaceColor', 'r', 'MarkerSize', 4);
set(gr2(2),'LineStyle','none','Marker','o','Color','g','MarkerFaceColor', 'g', 'MarkerSize', 4);
set(gr2(3),'LineStyle','none','Marker','o','Color','b','MarkerFaceColor', 'b', 'MarkerSize', 4);
set(gr2(4),'LineStyle','-','Color','k','LineWidth',3);
set(gr2(5),'LineStyle','-','Color','k','LineWidth',3);
set(gr2(6),'LineStyle','-','Color','k','LineWidth',3);