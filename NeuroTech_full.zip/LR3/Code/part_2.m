clear all;
close all;

t=2.5:0.01:5;
% x = @(t) sin(sin(t).*t.*t + 3*t - 10);

x = sin(sin(t).*t.*t+3*t-10);

gr = plot(t,x);grid;
set(gr(1),'LineStyle','-','Color','r','LineWidth',3);

[trainInd, valInd] = divideind(size(x,2),1:round(size(x,2)*0.9),round(size(x,2)*0.9)+1:size(x,2));

Trx = t(trainInd);
Valx = t(valInd);

Try = x(trainInd);
Valy = x(valInd);

net = feedforwardnet(15);%��� 2 �����
% net = feedforwardnet(8);%��� 3 �����
net = configure(net,[2.5,5],[-1,1]);

% net.layers{2}.transferFcn = 'tansig';
net.trainFcn = 'traincgb';%����� �������-����� (����� ����. ����.)
% net.trainFcn = 'trainbfg';
net.divideFcn = 'divideind';

net.divideParam.trainInd = 1:size(Trx,2);
net.divideParam.valInd=size(Trx,2)+1:size(Trx,2)+size(Valx,2);
net.divideParam.testInd=[];

%net.inputweights{1,1}.initFcn = 'rands';
%net.biases{1}.initFcn = 'rands';

display(net);
view(net);

init(net);

net.trainParam.epochs = 600;
net.trainParam.max_fail = 600;
net.trainParam.goal = 1E-8;

P = [Trx, Valx];
T = [Try, Valy];

IW_1 = net.IW;
b_1 = net.b;

[net,tr] = train(net,P,T);

IW_2 = net.IW;
b_2 = net.b;

xr = sim(net,Trx);
xv = sim(net,Valx);

E1 = Try - xr;
M3 = sqrt(mse(xr-Try))
MAE3 = mae(E1, xr, Try)
MAPE3= mean((abs(xr-Try))./Try)
R2 = 1 - sum((Try - xr).^2)/sum((Try - mean(xr)).^2)
min_ae = min(abs(Try - xr))
max_ae = max(abs(Try - xr))
SKO1 = M3/((max(xr) - min(xr)))

E_1 = 0;
E_2 = 0;
E_3 = 0;
E_4 = 0;
E_5 = 0;

for i=1:length(E1)
    if abs(E1(i)) < 0.05
        E_1 = E_1 + 1;
    end;
    if(abs(E1(i))>=0.05)&&(abs(E1(i))<0.1)
        E_2 = E_2 + 1;
    end;
    if(abs(E1(i))>=0.1&&(abs(E1(i))<0.2))
        E_3 = E_3 + 1;
    end;
    if(abs(E1(i))>=0.2&&(abs(E1(i))<0.3))
        E_4 = E_4 + 1;
    end;
    if(abs(E1(i))>=0.3)
        E_5 = E_5 + 1;
    end;
end;

E_1 = E_1/length(E1)
E_2 = E_2/length(E1)
E_3 = E_3/length(E1)
E_4 = E_4/length(E1)
E_5 = E_5/length(E1)

figure;
gr = plot(t,x,Trx,xr,Valx,xv);grid;
set(gr(1), 'LineStyle', '-', 'Color','r','LineWidth',2);
set(gr(2), 'LineStyle', '-', 'Color','g','LineWidth',2);
set(gr(3), 'LineStyle', '-', 'Color','b','LineWidth',2);