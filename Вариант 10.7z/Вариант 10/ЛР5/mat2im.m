function im = mat2im(mat)
    [m, n] = size(mat);

    mat_scaled = (mat + 1) / 2;

    im = zeros(m, n, 3);

    for y = 1:m
        for x = 1:n
            im(y, x, :) = [mat_scaled(y, x) mat_scaled(y, x) mat_scaled(y, x)];
            im(y, x, :) = [mat_scaled(y, x) mat_scaled(y, x) mat_scaled(y, x)];
            im(y, x, :) = [mat_scaled(y, x) mat_scaled(y, x) mat_scaled(y, x)];
        end
    end

end

